// package Assignment_1;
// import org.junit.jupiter.api.Test;

// import java.io.IOException;
// import java.util.ArrayList;

// import static org.junit.jupiter.api.Assertions.*;

// public class BackgroundTest {

//     // Test if the new curr is alraedy exist or not
//     @Test
//     public void TestAddNewCurr() {
//         Background b = new Background();
//         try {
//             b.add_new("NZD");
//         } catch (Exception e) {
//             e.printStackTrace();
//         }
//     }

//     // Test if the new curr is alraedy exist or not
//     @Test
//     public void TestAddNewCurr1() {
//         Background b = new Background();
//         try {
//             b.add_new("BRL");
//         } catch (Exception e) {
//             e.printStackTrace();
//         }
//     }

//     // Test if the new curr is alraedy exist or not
//     @Test
//     public void TestNewUser() {
//         Background b = new Background();
//         try {
//             b.new_user("Cat", "imacat", true);
//         } catch (Exception e) {
//             e.printStackTrace();
//         }
//     }

//     // s

// //    // Test if we can set new rate
// //    @Test
// //    public void TestNewRate() {
// //        Background b = new Background();
// //        try {
// //            b.new_rate("AUD", "CNY", 12.3);
// //        } catch (IOException e) {
// //            e.printStackTrace();
// //        }
// //     }

//     // Test if ew can use calculator
//     @Test
//     public void TestCalculator() {
//         Background b = new Background();
//         b.calculator("USD", "AUD", 1.4);
//     }

//     // Test if we can see max rate
//     @Test
//     public void TestMin() {
//         Background b = new Background();
//         double[] d = new double[2];
//         d[0] = 0.5;
//         d[1] = 0.9;
//         b.min(d);
//     }

//     // Test if we can see min rate
//     @Test
//     public void TestMax() {
//         Background b = new Background();
//         double[] d = new double[2];
//         d[0] = 0.5;
//         d[1] = 0.9;
//         b.max(d);
//     }

//     // Test if we can see average rate
//     @Test
//     public void TestAverage() {
//         Background b = new Background();
//         double[] d = new double[2];
//         d[0] = 0.5;
//         d[1] = 0.9;
//         b.average(d);
//     }
// }
// package Assignment_1;
// import org.junit.jupiter.api.Test;

// import java.io.IOException;
// import java.util.ArrayList;

// import static org.junit.jupiter.api.Assertions.*;

// public class BackgroundTest {

//     // Test if the new curr is alraedy exist or not
//     @Test
//     public void TestAddNewCurr() {
//         Background b = new Background();
//         try {
//             b.add_new("NZD");
//         } catch (Exception e) {
//             e.printStackTrace();
//         }
//     }

//     // Test if the new curr is alraedy exist or not
//     @Test
//     public void TestAddNewCurr1() {
//         Background b = new Background();
//         try {
//             b.add_new("BRL");
//         } catch (Exception e) {
//             e.printStackTrace();
//         }
//     }

//     // Test if the new curr is alraedy exist or not
//     @Test
//     public void TestNewUser() {
//         Background b = new Background();
//         try {
//             b.new_user("Cat", "imacat", true);
//         } catch (Exception e) {
//             e.printStackTrace();
//         }
//     }

//     // s

// //    // Test if we can set new rate
// //    @Test
// //    public void TestNewRate() {
// //        Background b = new Background();
// //        try {
// //            b.new_rate("AUD", "CNY", 12.3);
// //        } catch (IOException e) {
// //            e.printStackTrace();
// //        }
// //     }

//     // Test if ew can use calculator
//     @Test
//     public void TestCalculator() {
//         Background b = new Background();
//         b.calculator("USD", "AUD", 1.4);
//     }

//     // Test if we can see max rate
//     @Test
//     public void TestMin() {
//         Background b = new Background();
//         double[] d = new double[2];
//         d[0] = 0.5;
//         d[1] = 0.9;
//         b.min(d);
//     }

//     // Test if we can see min rate
//     @Test
//     public void TestMax() {
//         Background b = new Background();
//         double[] d = new double[2];
//         d[0] = 0.5;
//         d[1] = 0.9;
//         b.max(d);
//     }

//     // Test if we can see average rate
//     @Test
//     public void TestAverage() {
//         Background b = new Background();
//         double[] d = new double[2];
//         d[0] = 0.5;
//         d[1] = 0.9;
//         b.average(d);
//     }
// }
